package tests
import org.scalatest.FunSuite
import store.model.checkout.SelfCheckout
import store.model.items.Item
import store.model.items.Sale
import store.model.items.SalesTax
import store.model.items.BottleDeposit
import store.model.checkout.{InitialSCO, SelfCheckout}

class Task2 extends FunSuite {

  // assert(Math.abs(blah blah blah) < 0.0001)

  test("1 - with Modifiers.") {
    val testSelfCheckout: SelfCheckout = new SelfCheckout()
    //
    val apple: Item = new Item("apple", 2.00)
    val banana: Item = new Item("banana", 0.89)
    val blueberry: Item = new Item("blueberry", 1.80)
    val soda: Item = new Item ("soda", 2.00)
    //
    testSelfCheckout.addItemToStore("01110", apple)
    testSelfCheckout.addItemToStore("101010", banana)
    testSelfCheckout.addItemToStore("110010111", blueberry)
    testSelfCheckout.addItemToStore("1010", soda)
    //
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed()                       // apple is added to the cart!
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed()                       // soda is added to the cart!
    //
    var appleincart = testSelfCheckout.itemsInCart()(0)
    var sodaincart = testSelfCheckout.itemsInCart()(1)
    assert(Math.abs(appleincart.price() - 2.00) < 0.0001, "test 1") // checks to see price has not changed b4 modifiers.
    val applesale1: Sale = new Sale (20.0)
    appleincart.addModifier(applesale1)                                // adds modifiers to the list.
    val applesale2: Sale = new Sale(10.0)
     appleincart.addModifier(applesale2)
    val appletax: SalesTax = new SalesTax(10.0)
    appleincart.addModifier(appletax)
    val sodadep: BottleDeposit = new BottleDeposit(0.20)
    sodaincart.addModifier(sodadep)

    //
    appleincart.price()                                                  // applies the modifiers.
    assert(Math.abs(appleincart.price() - 1.44) < 0.0001, "test 2")   // checks the two sale were applied.
    appleincart.tax()
     assert(Math.abs(appleincart.tax() - 0.144) < 0.0001, "test 3")    // checks the sale tax was applied.
    sodaincart.price()
    assert(Math.abs(sodaincart.price() - 2.00) < 0.0001, "test 4")    // checks the price is untouched.
    sodaincart.tax()
    assert(Math.abs(sodaincart.tax() - 0.20) < 0.0001, "test 5")      // checks bottledeposit is in the tax.
    val sodatax: SalesTax = new SalesTax(10.0)
    sodaincart.addModifier(sodatax)
    sodaincart.tax()
    assert(Math.abs(sodaincart.tax() - 0.40) < 0.0001, "test 6")      // checks bottledeposit + tax is applied.
    //

    assert(Math.abs(testSelfCheckout.subtotal() - (3.44)) < 0.0001, "test 7")
    assert(Math.abs(testSelfCheckout.tax() - 0.544) < 0.0001, "test 8")
    assert(Math.abs(testSelfCheckout.total() - 3.984) < 0.0001, "test 9")



  }
}
