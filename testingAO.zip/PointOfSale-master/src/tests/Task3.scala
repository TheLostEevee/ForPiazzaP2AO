package tests
import org.scalatest.FunSuite
import store.model.checkout
import store.model.checkout.{InitialSCO, SelfCheckout}
import store.model.items
import store.model.items.{BottleDeposit, Item, Sale, SalesTax}

class Task3 extends FunSuite {

  test("1 - testing") {
    val testSelfCheckout: SelfCheckout = new SelfCheckout()
    //
    val apple: Item = new Item("apple", 2.00)
    val banana: Item = new Item("banana", 0.89)
    val blueberry: Item = new Item("blueberry", 1.80)
    val soda: Item = new Item("soda", 2.00)
    //
    testSelfCheckout.addItemToStore("01110", apple)
    testSelfCheckout.addItemToStore("101010", banana)
    testSelfCheckout.addItemToStore("110010111", blueberry)
    testSelfCheckout.addItemToStore("1010", soda)
    //
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed() // apple is added to the cart!
    testSelfCheckout.enterPressed()
    testSelfCheckout.enterPressed() // should add 3 apples to the cart.
    assert(testSelfCheckout.itemsInCart()(0).description() == "apple", "test 1")
    assert(testSelfCheckout.itemsInCart()(1).description() == "apple", "test 2")
    assert(testSelfCheckout.itemsInCart()(2).description() == "apple", "test 3")
    assert(testSelfCheckout.displayString() == "", "test 4") // test that the barcode is still empty.
    //
    testSelfCheckout.numberPressed(5)
    testSelfCheckout.clearPressed()
    testSelfCheckout.enterPressed() // should add an error to the cart.
    assert(testSelfCheckout.itemsInCart()(3).description() == "error", "test 5")
    assert(testSelfCheckout.displayString() == "", "test 6") // test that the barcode is still empty.
    //
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0) // adds soda to the cart!
    testSelfCheckout.enterPressed()
    //testSelfCheckout.cashPressed() // SHOULD AFFECT NOTHING.
    //testSelfCheckout.creditPressed() // SHOULD AFFECT NOTHING.
    //testSelfCheckout.loyaltyCardPressed() // SHOULD AFFECT NOTHING.
    testSelfCheckout.enterPressed()
    assert(testSelfCheckout.itemsInCart()(4).description() == "soda", "test 7")
    assert(testSelfCheckout.itemsInCart()(5).description() == "soda", "test 8")
    testSelfCheckout.checkoutPressed()
    assert(testSelfCheckout.displayString() == "cash or credit", "test 9")
    testSelfCheckout.creditPressed()
    assert(testSelfCheckout.itemsInCart() == List(), "test 10")
    assert(testSelfCheckout.displayString() == "", "test 11")
    testSelfCheckout.enterPressed()
    assert(testSelfCheckout.itemsInCart()(0).description() == "error", "test 12")


    //

  }
}
