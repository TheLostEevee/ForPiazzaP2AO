package tests

import org.scalatest.FunSuite
import store.model.items.Item
import store.model.checkout.{InitialSCO, SelfCheckout}


class Task1 extends FunSuite {

  test("1 - multiple testing.") {
    val testSelfCheckout: SelfCheckout = new SelfCheckout()
    //
    val apple: Item = new Item("apple", 2.00)
    val banana: Item = new Item("banana", 0.89)
    val blueberry: Item = new Item("blueberry", 1.80)
    //
    testSelfCheckout.addItemToStore("01110", apple)
    testSelfCheckout.addItemToStore("101010", banana)
    testSelfCheckout.addItemToStore("110010111", blueberry)
    //
    assert(testSelfCheckout.displayString == "") // tests for barcode being empty b4 pressed.
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    assert(testSelfCheckout.displayString == "010") // tests to make sure numberpressed works.
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(0)
    assert(testSelfCheckout.displayString == "01000") // tests numberpressed again.
    testSelfCheckout.clearPressed()
    assert(testSelfCheckout.displayString == "") // tests to make sure the clear button works.
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed()             // checks enterPressed() works, get apple in the itemsInCart

    assert(Math.abs(testSelfCheckout.itemsInCart()(0).price() - 2.00) < 0.0001)
    assert(testSelfCheckout.itemsInCart()(0).description() == "apple")
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed()             // when pressed should send error to the cart

    assert(Math.abs(testSelfCheckout.itemsInCart()(1).price() - 0.00) < 0.0001)
    assert(testSelfCheckout.itemsInCart()(1).description() == "error")
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    apple.setBasePrice(5.00)
    assert(Math.abs(testSelfCheckout.itemsInCart()(0).price() - 5.00) < 0.0001)
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed()             // checks enterPressed() works, get apple in the itemsInCart

    assert(Math.abs(testSelfCheckout.itemsInCart()(2).price() - 5.00) < 0.0001)
    assert(testSelfCheckout.itemsInCart()(2).description() == "apple")
    /////////////////////////////////////////////////////////////////////////////////////////////////////////
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.numberPressed(1)
    testSelfCheckout.numberPressed(0)
    testSelfCheckout.enterPressed()

    assert(Math.abs(testSelfCheckout.itemsInCart()(3).price() - 0.89) < 0.001)
    assert(testSelfCheckout.itemsInCart()(3).description() == "banana")



  }
  test("2 - changing the base price.") {
    //    var testSelfCheckout: SelfCheckout = new SelfCheckout()
    //
    var apple: Item = new Item("apple", 2.00)
    var banana: Item = new Item("banana", 0.89)
    //
    apple.setBasePrice(5.00)
    apple.setBasePrice(3.00)
    banana.setBasePrice(420.69)
    //    testSelfCheckout.addItemToStore("123", testItem)

    assert(Math.abs(apple.price() - 3.00) < 0.0001)
    assert(Math.abs(banana.price() - 420.69) < 0.0001)
  }

}
