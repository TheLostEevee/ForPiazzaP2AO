package store.model.checkout
import store.model.items.Item

class COPressed(theSCO: SelfCheckout) extends SCOState (theSCO) {

  override def addItemToStore(barcode: String, item: Item): Unit = {
    this.sco.store = this.sco.store + (barcode -> item)
  }

  override def itemsInCart(): List[Item] = {
    clearPressed () // clears addtoCart
    this.sco.cart // calls the current value of the cart.
  }

  override def displayString(): String = {
    this.sco.barcode
  }

  override def numberPressed(number: Int): Unit = {
   // DOES NOTHING.
  }


  override def subtotal(): Double = {
    var result = 0.0
    // for each item in the cart, the loop will call the price of it and add it to the result variable and return it.
    for (i <- this.sco.cart) {
      result = result + i.price() // adds the price to the result.
    }
    result
  }

  override def tax(): Double = {
    var result = 0.0
    for (i <- this.sco.cart) {
      result = result + i.tax()
    }
    result
  }

  override def total(): Double = {
    //  should return the total amount the customer must pay to purchase all the items in their cart (subtotal + tax)
    val result: Double = subtotal() + tax()
    result
  }

  override def prepareStore(): Unit = {}

  override def updateLoyalItems(): Unit = {}
///////////////////////////////////////////////// NEW IMPLEMENTATION //////////////////////////////////////////////////////
  override def enterPressed(): Unit = { // makes it so that items cannot be scanned (does nothing).
  // DOES NOTHING.
  }

  override def clearPressed(): Unit = { // does nothing.
// DOES NOTHING.
  }

  override def cashPressed(): Unit = { // cashPressed will open up a new SelfCheckout for the next customer.
  // the cart should empty and introduce a clean new selfCheckOut for the next customer.
    this.sco.cart = List()
    this.sco.barcode = ""
    this.sco.state = new InitialSCO(this.sco)
  }

  override def creditPressed(): Unit = { // has same function as creditPressed() above.
    this.sco.cart = List()
    this.sco.barcode = ""
    this.sco.state = new InitialSCO(this.sco)
  }

  override def loyaltyCardPressed(): Unit = {}
  // should switch the SCO state to loyaltymode, call updateLoyalItems, and switch the state back to COPressed
  this.sco.state = new LoyaltyMode(this.sco)
  sco.updateLoyalItems
  this.sco.state = new COPressed(this.sco)

  override def checkoutPressed(): Unit = {} // already in Checkout, no need to do anything.

}


