package store.model.checkout
import store.model.items.{Item, LoyaltyItem}

class InitialSCO(theSCO: SelfCheckout) extends SCOState(theSCO) {
// THIS CLASS ACTS UPON THE STATE LISTED BELOW AND BASED ON THE STATE WILL PERFORM CERTAIN ACTIONS.

  override def addItemToStore(barcode: String, item: Item): Unit = {
    this.sco.store = this.sco.store + (barcode -> item) // adds a map of the item to the barcode and adds it to the "store"
  }

  override def numberPressed(number: Int): Unit = {
    // demonstrates which number was pressed
    sco.barcode += number.toString // adds the number to the barcode.
  }

  override def clearPressed(): Unit = {
    this.sco.barcode = "" // makes the barcode empty for new input.
    this.sco.addtoCart = new Item ("", 0.0)
  }

  override def enterPressed(): Unit = {
    val preresult: Item = sco.store.getOrElse(this.sco.barcode, sco.error) // checks if the item is in store,
    this.sco.addtoCart = preresult
    sco.cart = sco.cart :+ this.sco.addtoCart// adds item to the cart (List[Item])
    // SHOULD ADD A STATE TRANSITION HERE TO ADD THE ITEM AGAIN IF ENTERPRESSED IS HIT MORE THAN ONCE.
    this.sco.state = new SameItem(this.sco) // changes the state to SameItem
    this.sco.barcode = "" // clears the barcode for a new input to be placed in it
  }

  override def checkoutPressed(): Unit = {
    this.sco.barcode = "cash or credit"
    // A state should be created holding checkoutPressed() and add functionality to cashPressed and creditPressed
    this.sco.state = new COPressed(this.sco) // switches state to CheckOutPressed
    // TODO
  }

  def cashPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
    // TODO
  }

  def creditPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
    // TODO
  }

  override def loyaltyCardPressed(): Unit = {
    // THIS BUTTON SHOULD NOW SWITCH THE STATE OF THE SELF CHECKOUT.
    // we should be switching each item in the cart currently to LoyaltyItem
    // for loop that does
    this.sco.state = new LoyaltyMode(this.sco)
    sco.updateLoyalItems
    // TODO
  }

  override def displayString(): String = {
    // Returns a string of what was pressed, in the order it was pressed, and displays it back to the customer.
    this.sco.barcode // calls the current barcode presented at the top.
  }

  override def itemsInCart(): List[Item] = {
    //  This List contains all the items that have been scanned, in the order in which they were scanned.
    // It is expected that you will have multiple references to the same Item object in your
    //  cart if the same item was scanned multiple times.
    sco.clearPressed () // clears addtoCart
    this.sco.cart // calls the current value of the cart.
  }

  override def subtotal(): Double = {
    // should return to total price of all the items in the customer's cart (Do not include tax)
    var result = 0.0
    // for each item in the cart, the loop will call the price of it and add it to the result variable and return it.
    for (i <- this.sco.cart) {
      result = result + i.price() // adds the price to the result.
    }
    result
  }

  override def tax(): Double = {
    // should return the total tax of all the items in the customer's cart
    var result = 0.0
    for (i <- this.sco.cart) {
      result = result + i.tax()
    }
    result
  }

  override def total(): Double = {
    //  should return the total amount the customer must pay to purchase all the items in their cart (subtotal + tax)
    val result: Double = subtotal() + tax()
    result
  }

  override def updateLoyalItems(): Unit = {}

  override def prepareStore(): Unit = {
    // Similar to openMap in the Pale Blue Dot assignment, this method is not required and is
    // meant to help you run manual tests.
    //
    // This method is called by the GUI during setup. Use this method to prepare your
    // items and call addItemToStore to add their barcodes. Also add any sales/tax/etc to your
    // items.
    //
    // This method will not be called during testing and you should not call it in your tests.
    // Each test must setup its own items to ensure compatibility in AutoLab. However, you can
    // write a similar method in your Test Suite classes.

    // Example usage:
    //val testItem: Item = new Item("test item", 100.0)
    //this.addItemToStore("472", testItem)
    val apple: Item = new Item("apple", 2.00)
    val banana: Item = new Item("banana", 0.89)
    val blueberry: Item = new Item("blueberry", 1.80)
    val soda: Item = new Item("soda", 2.00)
    //
    this.addItemToStore("01110", apple)
    this.addItemToStore("101010", banana)
    this.addItemToStore("110010111", blueberry)
    this.addItemToStore("1010", soda)
  }
}
