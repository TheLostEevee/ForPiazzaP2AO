package store.model.checkout
import store.model.items.Item

abstract class SCOState (val sco: SelfCheckout) {

  def addItemToStore(barcode: String, item: Item): Unit
  def numberPressed(number: Int): Unit
  def displayString(): String
  def itemsInCart(): List[Item]
  def clearPressed(): Unit
  def enterPressed(): Unit
  def subtotal(): Double
  def tax(): Double
  def total(): Double
  def checkoutPressed(): Unit
  def cashPressed(): Unit
  def creditPressed(): Unit
  def loyaltyCardPressed(): Unit
  def updateLoyalItems(): Unit
  def prepareStore(): Unit

}
