package store.model.checkout

import store.model.items.Item

class SameItem (theSCO: SelfCheckout) extends SCOState(theSCO) {

  val sameitem = this.sco.addtoCart

  override def addItemToStore(barcode: String, item: Item): Unit = {
    this.sco.state = new InitialSCO(this.sco)
    sco.addItemToStore(barcode, item)  // does what addItemToStore normally does.

  }

  override def itemsInCart(): List[Item] = {
    this.sco.state = new InitialSCO(this.sco)
    sco.itemsInCart() // does what itemsInCart normally does.
  }

  override def numberPressed(number: Int): Unit = {
    this.sco.state = new InitialSCO(this.sco)
    sco.numberPressed(number)// does what numberPressed normally does.

  }

  override def clearPressed(): Unit = {
    // error should be added to the cart at this point B/C the customer tried to clear after an item was scanned.
    this.sco.cart = sco.cart :+ sco.error // adds error to the cart for clearing after scanning.
    this.sco.state = new InitialSCO(this.sco) // switches the state back to normal

  }
  override def displayString(): String = {
    this.sco.state = new InitialSCO(this.sco)
    sco.displayString()// does what displayString normally does.
  }

  override def enterPressed(): Unit = {
    sco.cart = sco.cart :+ sameitem
    this.sco.barcode = "" // clears the barcode for a new input to be placed in it
  }

  def cashPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
    // TODO
  }

  def creditPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
    // TODO
  }

  def loyaltyCardPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
    // TODO
  }

  override def subtotal(): Double = {
    var result = 0.0
    // for each item in the cart, the loop will call the price of it and add it to the result variable and return it.
    for (i <- this.sco.cart) {
      result = result + i.price() // adds the price to the result.
    }
    result
  }

  override def tax(): Double = {
    var result = 0.0
    for (i <- this.sco.cart) {
      result = result + i.tax()
    }
    result
  }

  override def total(): Double = {
    val result: Double = subtotal() + tax()
    result
  }
  override def checkoutPressed(): Unit = {
    this.sco.barcode = "cash or credit"
    // A state should be created holding checkoutPressed() and add functionality to cashPressed and creditPressed
    this.sco.state = new COPressed(this.sco) // switches state to CheckOutPressed
  }

  override def prepareStore(): Unit = {}

  override def updateLoyalItems(): Unit = {}
}
