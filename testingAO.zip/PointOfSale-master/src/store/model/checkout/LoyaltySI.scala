package store.model.checkout
import store.model.items.Item

class LoyaltySI (theSCO: SelfCheckout) extends SCOState(theSCO) {
  // THIS STATE SHOULD NOW SWITCH YOU BACK TO LOYALTYMODE IN ALL BUTTONS EXCEPT ENTERPRESSED
  val sameitem = this.sco.addtoCart
  ///////////////////////////////////////////////////////////////////////////////////////////////////////
  override def prepareStore(): Unit = ???

  override def addItemToStore(barcode: String, item: Item): Unit = {
    this.sco.state = new LoyaltyMode(this.sco)
    sco.addItemToStore(barcode, item)  // does what addItemToStore normally does.
  }
  override def numberPressed(number: Int): Unit = {
    this.sco.state = new LoyaltyMode(this.sco)
    sco.numberPressed(number)// does what numberPressed normally does.
  }
  override def displayString(): String = {
    this.sco.state = new LoyaltyMode(this.sco)
    sco.displayString()// does what displayString normally does.
  }
  override def clearPressed(): Unit = {
    this.sco.cart = sco.cart :+ sco.error // adds error to the cart for clearing after scanning.
    this.sco.state = new LoyaltyMode(this.sco) // switches the state back to normal
  }
  override def enterPressed(): Unit = {
    sco.cart = sco.cart :+ sameitem
    this.sco.barcode = ""
  }

  override def itemsInCart(): List[Item] = {
    this.sco.state = new LoyaltyMode(this.sco)
    sco.itemsInCart() // does what itemsInCart normally does.
  }

  override def subtotal(): Double = {
    var result = 0.0
    // for each item in the cart, the loop will call the price of it and add it to the result variable and return it.
    for (i <- this.sco.cart) {
      result = result + i.price() // adds the price to the result.
    }
    result
  }
  override def tax(): Double = {
    var result = 0.0
    for (i <- this.sco.cart) {
      result = result + i.tax()
    }
    result
  }
  override def total(): Double = {
    val result: Double = subtotal() + tax()
    result
  }
  override def checkoutPressed(): Unit = {

    this.sco.barcode = "cash or credit"
    this.sco.state = new COPressed(this.sco) // switches state to CheckOutPressed
  }

  override def cashPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
  }
  override def creditPressed(): Unit = {
    // SHOULD DO NOTHING IN THIS STATE.
  }
  override def loyaltyCardPressed(): Unit = {
    this.sco.state = new LoyaltyMode(this.sco)
    // just to be sure...
    sco.updateLoyalItems
  }
  override def updateLoyalItems(): Unit = {} // does nothing in this state.
}

