package store.model.checkout
import store.model.items.Item
import store.model.items.{LoyaltyItem, RegItem, ItemState}


class LoyaltyMode (theSCO: SelfCheckout) extends SCOState(theSCO) {

  override def prepareStore(): Unit = {} // nothing.

  // initialSCO
  override def addItemToStore(barcode: String, item: Item): Unit = {
    this.sco.store = this.sco.store + (barcode -> item) // adds a map of the item to the barcode and adds it to the "store"
  }

  // initialSCO
  override def numberPressed(number: Int): Unit = {
    sco.barcode += number.toString // adds the number to the barcode.
  }

  // initialSCO
  override def displayString(): String = {
    this.sco.barcode // calls the current barcode presented at the top.
  }

  //initialSCO w/ some changes.
  override def enterPressed(): Unit = {
    val preresult: Item = sco.store.getOrElse(this.sco.barcode, sco.error) // checks if the item is in store
    preresult.state = new LoyaltyItem(preresult) // NEW: automatically switches the item to a loyalty state.
    this.sco.addtoCart = preresult
    sco.cart = sco.cart :+ this.sco.addtoCart// adds item to the cart (List[Item])
    this.sco.state = new LoyaltySI(this.sco) // changes the state to the Loyalty Version of SameItem
    this.sco.barcode = ""
  }

  // initialSCO
  override def itemsInCart(): List[Item] = {
    sco.clearPressed() // clears addtoCart
    this.sco.cart // calls the current value of the cart.
  }

  // NEW FEATURE!
  override def updateLoyalItems(): Unit = {
    // NEW FEATURE OF THE CLASS.
    // This method should access every item in the cart, switch the state of the item,
    // and then call the price() and tax () of these items to apply the LoyaltySale.
    for (i <- this.sco.cart) {
      i.state = new LoyaltyItem(i)
      i.price()
      i.tax()
    }
  }

  // initialSCO
  override def subtotal(): Double = {
    var result = 0.0
    // for each item in the cart, the loop will call the price of it and add it to the result variable and return it.
    for (i <- this.sco.cart) {
      result = result + i.price() // adds the price to the result.
    }
    result
  }

  // initialSCO
  override def tax(): Double = {
    var result = 0.0
    for (i <- this.sco.cart) {
      result = result + i.tax()
    }
    result
  }
  // initialSCO
  override def total(): Double = {
    val result: Double = subtotal() + tax()
    result
  }

  //initialSCO
  override def checkoutPressed(): Unit = {
    this.sco.state = new COPressed(this.sco)
  }

  // initialSCO; DOES NOTHING IN THIS STATE.
  override def creditPressed(): Unit = {}

  // initialSCO; DOES NOTHING IN THIS STATE.
  override def cashPressed(): Unit = {}

  // NEW FEATURE!
  override def loyaltyCardPressed(): Unit = {
    // should just maintain that the current state of the Selfcheckout is in LoyaltyMode.
    this.sco.state = new LoyaltyMode(this.sco)
    // just to be sure...
    sco.updateLoyalItems
  }

// initialSCO
  override def clearPressed(): Unit = {
    this.sco.barcode = "" // makes the barcode empty for new input.
    this.sco.addtoCart = new Item ("", 0.0)
  }
}

