package store.model.checkout

import store.model.items.Item

class SelfCheckout {

  var barcode: String = ""
  var store: Map [String, Item] = Map()
  var error: Item = new Item("error", 0.0)
  var addtoCart: Item = new Item("", 0.0)
  var cart: List [Item] = List ()
  //=======================================================================================================
var state: SCOState = new InitialSCO(this)

  def addItemToStore(barcode: String, item: Item): Unit = {this.state.addItemToStore(barcode, item)}
  def numberPressed(number: Int): Unit = {this.state.numberPressed(number)}
  def clearPressed(): Unit = {this.state.clearPressed()}
  def enterPressed(): Unit = {this.state.enterPressed()}
  def displayString(): String = {this.state.displayString()}
  def itemsInCart(): List[Item] = {this.state.itemsInCart()}
  def cashPressed(): Unit = {this.state.cashPressed()}
  def creditPressed(): Unit = {this.state.creditPressed()}
  def loyaltyCardPressed(): Unit = {this.state.loyaltyCardPressed()}
  def checkoutPressed(): Unit = {this.state.checkoutPressed()}
  def subtotal(): Double = {this.state.subtotal()}
  def tax(): Double = {this.state.tax()}
  def total(): Double = {this.state.total()}
  def updateLoyalItems: Unit = {this.state.updateLoyalItems()}
  def prepareStore(): Unit = {this.state.prepareStore()}



}
