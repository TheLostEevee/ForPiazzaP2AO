package store.model.items
import store.model.items.Modifier
import store.model.items.Sale
import store.model.items.BottleDeposit

class Item (var ItemDescript: String, var ItemPrice: Double) {

  var modifierList: List[Modifier] = List()
//
var state: ItemState = new RegItem(this)
//
  def description(): String = {this.state.description()}
  def setBasePrice (change: Double): Unit = {this.state.setBasePrice(change)}
  def price(): Double = {this.state.price()}
  def addModifier(mod: Modifier): Unit = {this.state.addModifier(mod)}
  def tax(): Double = {this.state.tax()}

}
