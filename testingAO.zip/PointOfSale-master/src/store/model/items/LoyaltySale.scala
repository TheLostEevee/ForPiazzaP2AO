package store.model.items

class LoyaltySale (var loyalperc: Double) extends Modifier {
  override def updatePrice (beforemod: Double): Double = {
    val percent: Double = 100 - loyalperc     // gets the percentage the customer must pay after the sale is applied.
    val truepercent: Double = percent * 0.01    // changes percent into decimal
    val finalsale: Double = beforemod * truepercent // calculates the price the customer pays after sale applied.
    finalsale
  }

  override def computeTax(itemprice: Double): Double = {
    // There is no tax applied by a loyalty sale.
    0.0
  }
}
