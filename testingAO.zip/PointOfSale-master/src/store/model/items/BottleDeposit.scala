package store.model.items

class BottleDeposit (var depCharge: Double) extends Modifier {
  override def updatePrice(beforemod: Double): Double = {
    // gives the price untouched.
    beforemod
  }

  override def computeTax(itemprice: Double): Double = {
    depCharge
  }
}
