package store.model.items

class LoyaltyItem (theItem:Item) extends ItemState(theItem) {
 // A STATE THAT IS ACTIVATED WHEN THE LOYALTYCARDPRESSED() IS ACTIVATED

  override def description(): String = {
    // Returns the description of the item from the constructor as a string.
    aitem.ItemDescript
  }

  override def addModifier(mod: Modifier): Unit = {
    // After a modifier is added with this method, the modifier is applied to all future method calls.
    this.aitem.modifierList = this.aitem.modifierList :+ mod //adds the new mod to the list.
  }


  override def setBasePrice(change: Double): Unit = {
    // Will change the base price to the value of the parameter (the double).
    aitem.ItemPrice = change
  }

  override def tax(): Double = {
    // returns the total tax applied to this item from all of its modifiers
    // All taxes should be applied to the price of the item with modifiers applied (call price()).
    var result = 0.0 // this number is how much tax will be applied to the item.
    for (mods <- aitem.modifierList) {
      result = result + mods.computeTax (price())
    }
    result
  }

  override def price(): Double = {
    // Returns the current price of the item (a Double).
    var result = aitem.ItemPrice
    for (mods <- aitem.modifierList) {
      result = mods.updatePrice(result)
    }
    result
  }
}
