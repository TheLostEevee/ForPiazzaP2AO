package store.model.items

abstract class ItemState (val aitem: Item) {

  def description(): String
  def setBasePrice (change: Double): Unit
  def price(): Double
  def addModifier(mod: Modifier): Unit
  def tax(): Double
}
