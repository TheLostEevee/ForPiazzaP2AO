package store.model.items

abstract class Modifier {
  // THESE ARE DEFAULT IMPLEMENTATIONS THAT MUST BE OVERRIDDEN.

  def updatePrice (beforemod: Double): Double
  // input is the item price BEFORE the modifier, the output is item price AFTER the modifier.
  def computeTax(itemprice: Double): Double
  // input is the item price before tax, the output is the amount of tax to be charged by the modifier.


}
