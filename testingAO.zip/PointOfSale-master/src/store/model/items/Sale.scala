package store.model.items

class Sale (var salePercent: Double) extends Modifier  {
  // Constructor is the percentage of the sale.
  override def updatePrice(beforemod: Double): Double = {
    // The input is the price before the sale is applied
    // The output is the new price with the sale applied.
    val percent: Double = 100 - salePercent     // gets the percentage the customer must pay after the sale is applied.
    val truepercent: Double = percent * 0.01    // changes percent into decimal
    val finalsale: Double = beforemod * truepercent // calculates the price the customer pays after sale applied.
    finalsale                                   // done!
  }

  override def computeTax(itemprice: Double): Double = {
    0.0
  }
}
