package store.model.items

class SalesTax (var STPercent: Double) extends Modifier {

  override def updatePrice(beforemod: Double): Double = {
    // gives the price untouched.
    beforemod
  }

  override def computeTax(itemprice: Double): Double = {
    //return the amount of sales tax that should be charged based on the input(price of item)
    val truepercent: Double = STPercent * 0.01 // changes the percent into a decimal.
    val result: Double = itemprice * truepercent // calculates the sales tax.
    result
  }
}
